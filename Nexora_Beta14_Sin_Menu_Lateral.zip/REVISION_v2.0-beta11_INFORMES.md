# Nexora 2.0-beta11 — Informes profesionales

## Cambios del módulo Informes
- Generador de informes por tipo: ejecutivo, incidencias abiertas, resueltas, urgentes, por departamento, por técnico y por software/equipo.
- Filtros de período: todos los registros, últimos 7 días, últimos 30 días y año actual.
- Vista previa de indicadores calculados a partir de los registros seleccionados.
- Exportación del subconjunto filtrado a PDF, CSV compatible con hojas de cálculo, HTML, TXT y JSON.
- PDF multipágina generado localmente; HTML con tabla, indicadores y estilos de impresión.
- Campos sin información se mantienen vacíos: el informe no inventa métricas.
- Se conserva el almacenamiento local y la exportación CSV/copia JSON de Ajustes.

## Validación
No se ejecutó una compilación Android en este entorno. Ejecutar el workflow de GitHub Actions «Compilar Nexora APK» y comprobar PDF/CSV/HTML/TXT/JSON en el dispositivo antes de distribuir.
