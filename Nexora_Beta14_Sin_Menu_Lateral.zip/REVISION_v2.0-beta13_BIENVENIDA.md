# Nexora 2.0 Beta 13 — bienvenida sin icono nativo

## Cambios
- Se sustituyó el icono de la pantalla de arranque nativa de Android por un recurso transparente para evitar que aparezca el icono antes de la bienvenida animada.
- Se conserva la pantalla de bienvenida Compose existente: halo azul/cian pulsante, entrada gradual del logotipo, aparición secuencial del nombre y lema, y transición suave hacia la aplicación.
- No se cambia la arquitectura de datos ni se implementa la futura conexión con SQL Server.

## Validación
- Cambio de recursos XML realizado y revisado.
- La compilación Android y las pruebas en dispositivo no se han ejecutado en este entorno; deben verificarse antes de distribuir el APK.


## Ajuste visual solicitado (preparación Beta 14)
- Se elimina el botón de menú lateral del banner compartido.
- Se desactivan los gestos de apertura del menú lateral para que no aparezca el drawer estilo ChatGPT.
- Se conserva el banner Nexora compartido, la navegación inferior, las pantallas y la animación de bienvenida ya presentes en esta base.
- Este cambio es de código fuente. No se ha podido verificar mediante compilación Android ni instalación en dispositivo en este entorno.
