# Nexora 2.0-beta12 — Auditoría e integración

## Base y compatibilidad
- Se conserva el proyecto Android Kotlin + Jetpack Compose y el `applicationId` `com.registroinformatico.app`.
- Se mantienen los módulos Inicio, Reportes, Análisis, Informes y Ajustes, el almacenamiento local `SharedPreferences`, el modelo `Report` y la identidad visual oscura azul/cian.
- No se cambia el esquema de almacenamiento local ni se elimina ningún campo del reporte.
- Versión actualizada de forma coherente a `2.0-beta12`, `versionCode = 13` y artefacto `NEXORA-APK-v2.0-beta12`.

## Correcciones de auditoría
- Corregido un paréntesis faltante en el modificador del panel de navegación que provocaba error de sintaxis Kotlin.
- Corregida la expresión de escape de comillas HTML.
- Gráfico de evolución agrupado y ordenado por marcas temporales reales, no por orden alfabético de etiquetas.
- Comparaciones de día, mes y año alineadas al mismo tramo temporal anterior; los rangos personalizados y períodos móviles mantienen comparación de duración equivalente.
- Normalización de estados resueltos/pendientes/en progreso al calcular indicadores.
- Exportación CSV ampliada con ID, fecha legible, marcas temporales de apertura/cierre y campos completos del reporte. La importación sigue aceptando CSV anteriores, conserva fechas cuando están presentes y evita colisiones de ID al anexar datos.
- Informes TXT, HTML y PDF incluyen más campos operativos; el HTML tiene estilos de impresión horizontal. Los informes por departamento, técnico y software/equipo se ordenan por su dimensión y prioridad/urgencia tiene un orden operativo.
- Los filtros de últimos 7/30 días excluyen marcas temporales futuras.
- Los exportadores ahora reportan error si Android no puede abrir el destino seleccionado, en lugar de indicar falsamente que se guardó.

## Validaciones realizadas en este entorno
- Estructura de Kotlin analizada con el compilador disponible; no se detectaron errores de sintaxis tras las correcciones.
- Revisión de coherencia de versión, estructura de proyecto, recursos y workflow.
- Las funciones CSV se probaron de forma aislada con el compilador Kotlin disponible: ida y vuelta de ID, fecha de apertura, fecha de cierre, comillas, separadores, campos y lectura de un CSV legado. El ZIP final pasó `unzip -t` sin errores de integridad.

## Validación que aún requiere GitHub Actions o entorno Android
No hay Gradle ni SDK Android instalados en este entorno; por tanto, no se afirma que el APK haya compilado ni que se hayan ejecutado pruebas en dispositivo. La comprobación final es ejecutar `Compilar Nexora APK` y probar creación/edición/cierre/eliminación de reportes, importación/restauración, rangos y comparaciones, y los cinco formatos de exportación.
